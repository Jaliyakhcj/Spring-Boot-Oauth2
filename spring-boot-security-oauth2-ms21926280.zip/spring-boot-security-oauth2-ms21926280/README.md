Reg. No: MS21926280
Name: K.H.C.J.Kumarasinghe
Email: jaliyak@gmail.com
Phone: +94773237461
Github repo: https://github.com/Jaliyakhcj/Spring-Boot-Oauth2
Video: https://youtu.be/ZEm_nJSxc3k

